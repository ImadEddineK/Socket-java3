package sock;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;


public class client {

	
	public static void main(String args[]) {
		InetAddress adr; 
		int x=5;  
		int [] tableau = new int [6];  
		tableau[0]=2; tableau[1]=5; tableau[2]=1; tableau[3]=3; tableau[4]=4; tableau[5]=0;  
		
		
		try {
			adr = InetAddress.getByName("localhost");
			try {
				Socket socket = new Socket(adr,122); 
				
				OutputStream out = socket.getOutputStream();  
				ObjectOutputStream oout = new ObjectOutputStream(out);  
				oout.writeObject(tableau);  
				oout.writeObject(x);
				
				InputStream in = socket.getInputStream();
				ObjectInputStream oin = new ObjectInputStream(in);
				String line =(String) oin.readObject();  
				System.out.println("message recue par le serveur "+line);
				
				System.out.println("l'addresse de serveur est "+socket.getRemoteSocketAddress());  
				System.out.println("l'adress de client "+socket.getLocalAddress());
				System.out.println("le port de client "+socket.getLocalPort());
				
				socket.close(); 
				
				
			} catch (IOException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
